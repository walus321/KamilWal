import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataAccessLayer {
    private static DataAccessLayer _layer;
    private Connection connection;
    
    public static DataAccessLayer getInstance() {
        if (_layer == null) {
            _layer = new DataAccessLayer();
        }
        
        return _layer;
    }
    
    private DataAccessLayer() {
        
    }
    
    public void open(String login, String password, String host, String port, String sid) throws SQLException {
        String DB_URL = "jdbc:oracle:thin:@" + host + ":" + port + ":" + sid;
        connection = DriverManager.getConnection(DB_URL, login, password);
    }
    
    public void close() {
        try {
            connection.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataAccessLayer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet query(String query) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(query);
        return statement.executeQuery();
    }
    
    public int nonQuery(String query) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(query);
        return statement.executeUpdate();
    }
}
